module.exports = {
    user: 1,
    admin: 2,
    senior:3
  };
  